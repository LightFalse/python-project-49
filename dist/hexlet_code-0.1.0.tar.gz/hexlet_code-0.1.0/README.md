### Hexlet tests and linter status:
[![Actions Status](https://github.com/LightFalse/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LightFalse/python-project-49/actions)
<a href="https://codeclimate.com/github/LightFalse/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b1778453eff5ccc86539/maintainability" /></a>
