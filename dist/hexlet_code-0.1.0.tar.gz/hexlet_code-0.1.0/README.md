### Hexlet tests and linter status:
[![Actions Status](https://github.com/LightFalse/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LightFalse/python-project-49/actions)
[CodeClimate]<a href="https://codeclimate.com/github/LightFalse/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b1778453eff5ccc86539/maintainability" /></a>
[asciinema.org]<a href="https://asciinema.org/a/J6uReA93Qm6QpNPWc1R8NKZCd" target="_blank"><img src="https://asciinema.org/a/J6uReA93Qm6QpNPWc1R8NKZCd.svg" /></a>