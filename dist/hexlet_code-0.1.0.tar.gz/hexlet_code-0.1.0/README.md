### Hexlet tests and linter status:
[![Actions Status](https://github.com/LightFalse/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LightFalse/python-project-49/actions)
[CodeClimate]<a href="https://codeclimate.com/github/LightFalse/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b1778453eff5ccc86539/maintainabil    ity" /></a>
#even <a href="https://asciinema.org/a/hyfrCyPKyzYJoOOStjFGqLtjA" target="_blank"><img src="https://asciinema.org/a/hyfrCyPKyzYJoOOStjFGqLtjA.svg" /></a>
#calc <a href="https://asciinema.org/a/jPgRqk7uZslbIIBlkTdWNy1OV" target="_blank"><img src="https://asciinema.org/a/jPgRqk7uZslbIIBlkTdWNy1OV.svg" /></a>
#gcd<a href="https://asciinema.org/a/865o7g9fb6vWBv7TCSGtI1LSA" target="_blank"><img src="https://asciinema.org/a/865o7g9fb6vWBv7TCSGtI1LSA.svg" /></a>